exports.handler = async (event,context,callback) => {
    var recor = event.currentIntent.slots.Tareas;
    var dia = event.currentIntent.slots.date;
    var hora = event.currentIntent.slots.time;
    var details = event.currentIntent.slots.detalles;
    // TODO implement
    callback(null,{
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
            "message": {
                "contentType": "PlainText",
                "content": "Su recordatorio de " + details + " en el apartado de " + recor + " se lo recordaremos el día " + dia + " a la hora " + hora
                
            }
        }
    });
};
