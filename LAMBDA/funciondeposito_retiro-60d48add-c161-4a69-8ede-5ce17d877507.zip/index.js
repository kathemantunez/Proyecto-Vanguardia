exports.handler = async (event,context,callback) => {
    // TODO implement
    var deposito = event.currentIntent.slots.dep;
    var retiro = event.currentIntent.slots.ret;
    var total = 0;
    let { name, slots } = event.currentIntent;
    if(slots.de_re === 'Agregar Deposito'&&!slots.dep){
         return {
            "dialogAction": {
                "type": "ElicitSlot",
                "intentName": "Ret_dep",
                "slotToElicit": "dep",
                slots
             }
        }
        
    }else if(slots.de_re === 'Agregar Retiro'&&!slots.ret){
         return {
            "dialogAction": {
                "type": "ElicitSlot",
                "intentName": "Ret_dep",
                "slotToElicit": "ret",
                slots
             }
        }
        
    }else{
        if(deposito===null){
            total = retiro;
            
        }else{
            total = deposito;
            
        }
            callback(null,{
                "dialogAction": {
                    "type": "Close",
                    "fulfillmentState": "Fulfilled",
                    "message": {
                        "contentType": "PlainText",
                        "content": "Gracias su transacción de " + total + " lempiras se ha registrado correctamente!"
                
                    }
                    
                }
            });
        
    }
   
};
