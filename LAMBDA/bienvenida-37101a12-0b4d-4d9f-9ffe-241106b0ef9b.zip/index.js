exports.handler = async (event) => {
    let { name, slots } = event.currentIntent;
    if ((slots.bienve === 'Recordarme')||(slots.bienve === 'Agregar Tarjeta')||
    (slots.bienve === 'Transacciones')){
        return {
             "dialogAction": {
                "type": "ElicitIntent"
             }
        }
    }
};
